const chatWindow = document.getElementById('chatWindow');

let currentStep = 'menu';
let userSelection = null;

// Validation functions
function validateEmail(email) {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email.trim());
}

function validatePhone(phone) {
  // Remove all non-digit characters
  const cleanPhone = phone.replace(/\D/g, '');
  
  // Brazilian phone formats: 10 or 11 digits (with DDD)
  // Accept formats: (XX) XXXX-XXXX, (XX) XXXXX-XXXX, XX XXXX XXXX, etc.
  if (cleanPhone.length === 10 || cleanPhone.length === 11) {
    // Check if it starts with valid DDD (11-99, excluding some invalid ones)
    const ddd = cleanPhone.substring(0, 2);
    const validDDD = ['11', '12', '13', '14', '15', '16', '17', '18', '19',
                     '21', '22', '24', '27', '28', '31', '32', '33', '34',
                     '35', '37', '38', '41', '42', '43', '44', '45', '46',
                     '47', '48', '49', '51', '53', '54', '55', '61', '62',
                     '63', '64', '65', '66', '67', '68', '69', '71', '73',
                     '74', '75', '77', '79', '81', '82', '83', '84', '85',
                     '86', '87', '88', '89', '91', '92', '93', '94', '95',
                     '96', '97', '98', '99'];
    
    return validDDD.includes(ddd);
  }
  
  return false;
}

function formatPhone(phone) {
  const cleanPhone = phone.replace(/\D/g, '');
  
  if (cleanPhone.length === 11) {
    return cleanPhone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  } else if (cleanPhone.length === 10) {
    return cleanPhone.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  }
  
  return phone;
}

function validateForm(data) {
  const errors = [];
  
  // Validate name
  if (!data.nome || data.nome.trim().length < 2) {
    errors.push('nome deve ter pelo menos 2 caracteres');
  }
  
  // Validate email
  if (!data.email) {
    errors.push('e-mail é obrigatório');
  } else if (!validateEmail(data.email)) {
    errors.push('e-mail inválido');
  }
  
  // Validate phone
  if (!data.whatsapp) {
    errors.push('WhatsApp é obrigatório');
  } else if (!validatePhone(data.whatsapp)) {
    errors.push('WhatsApp inválido. Use formato: (XX) XXXXX-XXXX ou (XX) XXXX-XXXX');
  }
  
  return errors;
}

const responses = [
  {
    match: /ideia|sugestão|novo caminho|inovar|inovação/i,
    answer: 'Estruture a ideia em três passos: problema claro, solução objetiva e entrega com controle. Isso reduz riscos e mostra perfil de alta performance.'
  },
  {
    match: /dúvida|erro|problema|incerteza/i,
    answer: 'Identifique o cerne da dúvida, elimine suposições e adote uma solução prática. A resposta precisa ser direta e sem complicar o processo.'
  },
  {
    match: /como|estratégia|passo|processo/i,
    answer: 'Defina o objetivo antes de agir. Sem clareza no ponto de chegada, a execução perde autoridade e eficácia.'
  },
  {
    match: /maquiagem|design|visual|interface/i,
    answer: 'O visual deve servir à função. Use contraste, espaço e simplicidade para comunicar segurança e controle.'
  }
];

function createMessage(text, type) {
  const message = document.createElement('div');
  message.className = `message ${type}`;
  
  if (text.includes('**')) {
    message.innerHTML = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  } else {
    message.textContent = text;
  }
  
  chatWindow.appendChild(message);
  
  // Trigger fade-in animation
  setTimeout(() => {
    message.classList.add('active');
  }, 50);
  
  // Scroll to bottom
  ensureBottomView();
  
  return message;
}

function clearChatWindow() {
  const messages = chatWindow.querySelectorAll('.message, .options-container, .chat-form-container, .services-container, .whatsapp-button-enhanced');
  messages.forEach(msg => {
    msg.remove();
  });
}

function createButton(text, onClick) {
  const button = document.createElement('button');
  button.className = 'chat-option-button';
  button.textContent = text;
  button.addEventListener('click', onClick);
  return button;
}

function createForm(fields, onSubmit) {
  const form = document.createElement('div');
  form.className = 'chat-form-container';
  
  fields.forEach(field => {
    const input = document.createElement('input');
    input.type = field.type || 'text';
    input.placeholder = field.placeholder;
    input.className = 'chat-input-field';
    input.dataset.field = field.name;
    
    // Add real-time validation
    input.addEventListener('input', () => {
      validateField(input, field.name);
    });
    
    input.addEventListener('blur', () => {
      validateField(input, field.name);
    });
    
    form.appendChild(input);
  });
  
  const submitBtn = document.createElement('button');
  submitBtn.className = 'chat-submit-button';
  submitBtn.textContent = 'Enviar';
  submitBtn.addEventListener('click', () => {
    const data = {};
    let hasErrors = false;
    
    form.querySelectorAll('input').forEach(input => {
      data[input.dataset.field] = input.value;
      
      // Validate each field on submission
      if (!validateField(input, input.dataset.field)) {
        hasErrors = true;
      }
    });
    
    if (!hasErrors) {
      onSubmit(data);
    }
  });
  
  form.appendChild(submitBtn);
  return form;
}

function validateField(input, fieldName) {
  const value = input.value.trim();
  let isValid = true;
  let errorMessage = '';
  
  // Remove previous styling classes
  input.classList.remove('error', 'success');
  
  // Remove existing error message if any
  const existingError = input.parentNode.querySelector('.field-error');
  if (existingError) {
    existingError.remove();
  }
  
  switch(fieldName) {
    case 'nome':
      if (!value || value.length < 2) {
        isValid = false;
        errorMessage = 'Nome deve ter pelo menos 2 caracteres';
      }
      break;
      
    case 'email':
      if (!value) {
        isValid = false;
        errorMessage = 'E-mail é obrigatório';
      } else if (!validateEmail(value)) {
        isValid = false;
        errorMessage = 'E-mail inválido';
      }
      break;
      
    case 'whatsapp':
      if (!value) {
        isValid = false;
        errorMessage = 'WhatsApp é obrigatório';
      } else if (!validatePhone(value)) {
        isValid = false;
        errorMessage = 'WhatsApp inválido. Use: (XX) XXXXX-XXXX';
      } else {
        // Format phone number as user types
        const formattedPhone = formatPhone(value);
        if (formattedPhone !== value) {
          input.value = formattedPhone;
        }
      }
      break;
  }
  
  if (!isValid) {
    // Add error class
    input.classList.add('error');
    
    // Create error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = errorMessage;
    
    input.parentNode.insertBefore(errorDiv, input.nextSibling);
    
    // Animate error message
    setTimeout(() => {
      errorDiv.classList.add('show');
    }, 50);
  } else if (value) {
    // Add success class if field has valid content
    input.classList.add('success');
  }
  
  return isValid;
}

function createOptionsContainer() {
  const container = document.createElement('div');
  container.className = 'options-container';
  return container;
}

function scrollChat() {
  setTimeout(() => {
    chatWindow.scrollTo({
      top: chatWindow.scrollHeight,
      behavior: 'smooth'
    });
  }, 100);
}

function scrollToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function ensureBottomView() {
  // Auto-scroll to keep last message visible
  setTimeout(() => {
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }, 100);
}

// Auto-scroll observer to keep user at bottom
function setupAutoScroll() {
  const observer = new MutationObserver(() => {
    ensureBottomView();
  });
  
  observer.observe(chatWindow, {
    childList: true,
    subtree: true,
    attributes: true,
    characterData: true
  });
  
  return observer;
}

function generateResponse(question) {
  const found = responses.find(item => item.match.test(question));
  if (found) {
    return found.answer;
  }
  return 'A pergunta exige precisão. Refaça o foco e pergunte com clareza para receber a solução correta.';
}

function showMainMenu() {
  clearChatWindow();
  currentStep = 'menu';
  
  const menuMessage = createMessage('Olá! Como posso ajudar você hoje?', 'bot');
  
  const optionsContainer = createOptionsContainer();
  
  const options = [
    { text: '1. Quero chatbot para vendas/conversão', action: handleOption1 },
    { text: '2. Preciso de um bot para Suporte/SAC', action: handleOption2 },
    { text: '3. Falar com um Consultor Humano / dúvidas', action: handleOption3 },
    { text: '4. Cancelamento de serviço', action: handleOption4 }
  ];
  
  options.forEach((option, index) => {
    const button = createButton(option.text, option.action);
    optionsContainer.appendChild(button);
  });
  
  chatWindow.appendChild(optionsContainer);
  
  // Trigger options container animation
  setTimeout(() => {
    optionsContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function handleOption1() {
  clearChatWindow();
  currentStep = 'option1';
  userSelection = 'vendas';
  
  const message = createMessage('Ótima escolha! Para começarmos, preciso de algumas informações:', 'bot');
  
  const form = createForm([
    { name: 'nome', placeholder: 'Seu nome completo' },
    { name: 'whatsapp', placeholder: '(XX) XXXXX-XXXX' },
    { name: 'email', placeholder: 'seu@email.com' }
  ], (data) => {
    const errors = validateForm(data);
    
    if (errors.length === 0) {
      // Format phone number for display
      data.whatsapp = formatPhone(data.whatsapp);
      showOption1Details(data);
    } else {
      const errorMsg = createMessage(`Por favor, corrija os seguintes erros:\n• ${errors.join('\n• ')}`, 'bot');
      ensureBottomView();
    }
  });
  
  chatWindow.appendChild(form);
  
  // Trigger form animation
  setTimeout(() => {
    form.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function showOption1Details(userData) {
  const confirmMessage = createMessage(`Obrigado ${userData.nome}! Recebemos suas informações. Nossas soluções de vendas incluem:`, 'bot');
  
  const servicesContainer = document.createElement('div');
  servicesContainer.className = 'services-container';
  
  const services = [
    {
      icon: '🛒',
      title: 'Recuperação de Carrinho',
      description: 'Automação via WhatsApp para converter boletos e Pix não pagos imediatamente.'
    },
    {
      icon: '🎯',
      title: 'Qualificação de Leads',
      description: 'Filtro inteligente de curiosos para entregar apenas clientes reais para o seu comercial.'
    },
    {
      icon: '📅',
      title: 'Agendamento Automático',
      description: 'Integração com agenda para marcar reuniões ou serviços sem intervenção humana.'
    },
    {
      icon: '🏪',
      title: 'Vitrine Digital',
      description: 'Catálogo interativo dentro do chat para fechamento direto via Pix/Cartão.'
    }
  ];
  
  services.forEach((service, index) => {
    const serviceCard = document.createElement('div');
    serviceCard.className = 'service-card';
    
    serviceCard.innerHTML = `
      <div class="service-icon">${service.icon}</div>
      <div class="service-content">
        <h4 class="service-title">${service.title}</h4>
        <p class="service-description">${service.description}</p>
      </div>
    `;
    
    servicesContainer.appendChild(serviceCard);
  });
  
  chatWindow.appendChild(servicesContainer);
  
  // Trigger services container animation
  setTimeout(() => {
    servicesContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
  
  const returnMessage = createMessage('Em breve nossa equipe entrará em contato via WhatsApp. Deseja voltar ao menu principal?', 'bot');
  
  const optionsContainer = createOptionsContainer();
  const returnBtn = createButton('Voltar ao Menu', () => {
    clearChatWindow();
    showMainMenu();
  });
  optionsContainer.appendChild(returnBtn);
  
  chatWindow.appendChild(optionsContainer);
  
  // Trigger options container animation
  setTimeout(() => {
    optionsContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function handleOption2() {
  clearChatWindow();
  currentStep = 'option2';
  userSelection = 'suporte';
  
  const message = createMessage('Perfeito! Para nosso suporte, preciso de algumas informações:', 'bot');
  
  const form = createForm([
    { name: 'nome', placeholder: 'Seu nome completo' },
    { name: 'whatsapp', placeholder: '(XX) XXXXX-XXXX' },
    { name: 'email', placeholder: 'seu@email.com' }
  ], (data) => {
    const errors = validateForm(data);
    
    if (errors.length === 0) {
      // Format phone number for display
      data.whatsapp = formatPhone(data.whatsapp);
      showOption2Details(data);
    } else {
      const errorMsg = createMessage(`Por favor, corrija os seguintes erros:\n• ${errors.join('\n• ')}`, 'bot');
      ensureBottomView();
    }
  });
  
  chatWindow.appendChild(form);
  
  // Trigger form animation
  setTimeout(() => {
    form.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function showOption2Details(userData) {
  const confirmMessage = createMessage(`Obrigado ${userData.nome}! Recebemos suas informações. Nossas soluções de suporte incluem:`, 'bot');
  
  const servicesContainer = document.createElement('div');
  servicesContainer.className = 'services-container';
  
  const services = [
    {
      icon: '🤖',
      title: 'FAQ Inteligente',
      description: 'Respostas imediatas para as 20 dúvidas mais frequentes dos seus clientes.'
    },
    {
      icon: '📦',
      title: 'Status de Pedido',
      description: 'Integração com seu sistema para rastreio e entrega automática de informações.'
    },
    {
      icon: '🔄',
      title: 'Triagem e Transbordo',
      description: 'O bot resolve o básico e envia o problema complexo já mastigado para o humano certo.'
    },
    {
      icon: '📊',
      title: 'Pesquisa de Satisfação',
      description: 'Coleta automática de NPS e feedback após cada atendimento concluído.'
    }
  ];
  
  services.forEach((service, index) => {
    const serviceCard = document.createElement('div');
    serviceCard.className = 'service-card';
    
    serviceCard.innerHTML = `
      <div class="service-icon">${service.icon}</div>
      <div class="service-content">
        <h4 class="service-title">${service.title}</h4>
        <p class="service-description">${service.description}</p>
      </div>
    `;
    
    servicesContainer.appendChild(serviceCard);
  });
  
  chatWindow.appendChild(servicesContainer);
  
  // Trigger services container animation
  setTimeout(() => {
    servicesContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
  
  const returnMessage = createMessage('Nossa equipe de suporte entrará em contato em breve. Deseja voltar ao menu principal?', 'bot');
  
  const optionsContainer = createOptionsContainer();
  const returnBtn = createButton('Voltar ao Menu', () => {
    clearChatWindow();
    showMainMenu();
  });
  optionsContainer.appendChild(returnBtn);
  
  chatWindow.appendChild(optionsContainer);
  
  // Trigger options container animation
  setTimeout(() => {
    optionsContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function handleOption3() {
  clearChatWindow();
  currentStep = 'option3';
  userSelection = 'consultor';
  
  const message = createMessage('Claro! Fale diretamente com nossos consultores:', 'bot');
  
  const servicesContainer = document.createElement('div');
  servicesContainer.className = 'services-container';
  
  const services = [
    {
      icon: '💼',
      title: 'Orçamento Personalizado',
      description: 'Briefing rápido para enviarmos uma proposta comercial sob medida.'
    },
    {
      icon: '🤝',
      title: 'Parcerias e Revenda',
      description: 'Para agências ou consultores que querem oferecer a tecnologia M.aKI.'
    }
  ];
  
  services.forEach((service, index) => {
    const serviceCard = document.createElement('div');
    serviceCard.className = 'service-card';
    
    serviceCard.innerHTML = `
      <div class="service-icon">${service.icon}</div>
      <div class="service-content">
        <h4 class="service-title">${service.title}</h4>
        <p class="service-description">${service.description}</p>
      </div>
    `;
    
    servicesContainer.appendChild(serviceCard);
  });
  
  chatWindow.appendChild(servicesContainer);
  
  // Trigger services container animation
  setTimeout(() => {
    servicesContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
  
  const whatsappBtn = document.createElement('button');
  whatsappBtn.className = 'whatsapp-button-enhanced';
  whatsappBtn.innerHTML = `
    <div class="whatsapp-icon-enhanced">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
        <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm.01 1.67c4.37 0 7.93 3.56 7.93 7.93 0 4.37-3.56 7.93-7.93 7.93-1.48 0-2.93-.41-4.2-1.19l-.3-.18-.31.08-1.26.33.33-1.22.09-.34-.2-.29a6.78 6.78 0 01-1.03-3.61c0-4.37 3.56-7.93 7.93-7.93zM9.09 7.42c-.14 0-.36.06-.53.22-.17.16-.68.66-.68 1.62s.69 1.88.79 2.01c.1.12 1.35 2.15 3.31 3.06.47.22.84.35 1.12.44.47.15.89.13 1.23.08.37-.06 1.13-.46 1.29-.91.16-.44.16-.82.11-.9-.05-.08-.17-.13-.36-.22-.19-.09-1.13-.56-1.31-.63-.17-.06-.3-.1-.43.1-.13.2-.51.63-.63.76-.12.12-.23.14-.42.04-.19-.09-.8-.3-1.52-.94-.56-.5-.94-1.11-1.05-1.3-.11-.19-.01-.3.08-.39.08-.09.19-.21.32-.35.13-.14.17-.23.25-.38.08-.15.04-.28-.02-.41-.06-.13-.27-.67-.37-.92-.1-.25-.2-.29-.36-.3H9.09z" fill="#ffffff"/>
      </svg>
    </div>
    <div class="whatsapp-text-enhanced">
      <span class="whatsapp-title-enhanced">Conectar com Consultor MAKI</span>
      <span class="whatsapp-subtitle">Iniciar conversa via WhatsApp</span>
      <span class="whatsapp-number-enhanced">(21) 99396-3770</span>
    </div>
    <div class="whatsapp-arrow">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" fill="#ffffff"/>
      </svg>
    </div>
  `;
  whatsappBtn.addEventListener('click', () => {
    window.open('http://wa.me/+5521993963770', '_blank');
  });
  
  chatWindow.appendChild(whatsappBtn);
  
  // Trigger WhatsApp button animation
  setTimeout(() => {
    whatsappBtn.classList.add('animate');
  }, 100);
  
  ensureBottomView();
  
  const returnMessage = createMessage('Nosso time está pronto para ajudar! Deseja voltar ao menu principal?', 'bot');
  
  const optionsContainer = createOptionsContainer();
  const returnBtn = createButton('Voltar ao Menu', () => {
    clearChatWindow();
    showMainMenu();
  });
  optionsContainer.appendChild(returnBtn);
  
  chatWindow.appendChild(optionsContainer);
  
  // Trigger options container animation
  setTimeout(() => {
    optionsContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function handleOption4() {
  clearChatWindow();
  currentStep = 'option4';
  userSelection = 'cancelamento';
  
  const message = createMessage('Sinto muito que você queira cancelar. Para processar o cancelamento, preciso do seu nome:', 'bot');
  
  const form = createForm([
    { name: 'nome', placeholder: 'Seu nome completo' }
  ], (data) => {
    if (!data.nome || data.nome.trim().length < 2) {
      const errorMsg = createMessage('Por favor, informe seu nome completo (mínimo 2 caracteres).', 'bot');
      ensureBottomView();
    } else {
      processCancellation(data.nome);
    }
  });
  
  chatWindow.appendChild(form);
  
  // Trigger form animation
  setTimeout(() => {
    form.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

function processCancellation(nome) {
  const confirmMessage = createMessage(`Serviço cancelado para ${nome} 👍🏻`, 'bot');
  chatWindow.appendChild(confirmMessage);
  
  const returnMessage = createMessage('Deseja voltar ao menu principal?', 'bot');
  chatWindow.appendChild(returnMessage);
  ensureBottomView();
  
  const optionsContainer = createOptionsContainer();
  const returnBtn = createButton('Voltar ao Menu', () => {
    clearChatWindow();
    showMainMenu();
  });
  optionsContainer.appendChild(returnBtn);
  chatWindow.appendChild(optionsContainer);
  
  // Trigger options container animation
  setTimeout(() => {
    optionsContainer.classList.add('active');
  }, 100);
  
  ensureBottomView();
}

// Theme Toggle Functionality
function initThemeToggle() {
  const themeToggle = document.getElementById('themeToggle');
  const html = document.documentElement;
  
  // Check for saved theme preference or default to light mode
  const savedTheme = localStorage.getItem('theme') || 'light';
  html.setAttribute('data-theme', savedTheme);
  
  // Update toggle button icon
  updateThemeToggleIcon(savedTheme);
  
  themeToggle.addEventListener('click', () => {
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    // Update theme
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update toggle button icon
    updateThemeToggleIcon(newTheme);
    
    // Add smooth transition effect
    document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
  });
}

function updateThemeToggleIcon(theme) {
  const sunIcon = document.querySelector('.sun-icon');
  const moonIcon = document.querySelector('.moon-icon');
  
  if (theme === 'dark') {
    sunIcon.style.display = 'none';
    moonIcon.style.display = 'block';
  } else {
    sunIcon.style.display = 'block';
    moonIcon.style.display = 'none';
  }
}

// Return Menu Button Functionality
function initReturnMenuButton() {
  const returnMenuBtn = document.getElementById('returnMenuBtn');
  
  if (returnMenuBtn) {
    returnMenuBtn.addEventListener('click', () => {
      clearChatWindow();
      showMainMenu();
    });
  }
}

// Initialize chat with menu
window.addEventListener('load', () => {
  // Initialize theme toggle first
  initThemeToggle();
  
  // Initialize return menu button
  initReturnMenuButton();
  
  showMainMenu();
  
  // Setup auto-scroll observer to keep last message visible
  setupAutoScroll();
  
  // Ensure bottom view on window resize
  window.addEventListener('resize', ensureBottomView);
});
